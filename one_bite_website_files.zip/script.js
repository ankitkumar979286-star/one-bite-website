const products = [
  {id:1,name:"Crunchy Classic Burger",description:"A satisfying classic with a big crunch.",price:129,emoji:"🍔"},
  {id:2,name:"Golden Crispy Fries",description:"Golden, crispy, and perfect for sharing.",price:79,emoji:"🍟"},
  {id:3,name:"Cheesy Pizza Slice",description:"Cheesy goodness in every bite.",price:99,emoji:"🍕"},
  {id:4,name:"Loaded Sandwich",description:"A tasty, filling bite for any time.",price:89,emoji:"🥪"},
  {id:5,name:"Chilled Cold Coffee",description:"Cool, creamy, and refreshing.",price:69,emoji:"🥤"},
  {id:6,name:"Sweet Donut",description:"A little sweetness to finish your meal.",price:59,emoji:"🍩"}
];
let cart = [];
const money = n => "₹" + n;
const productsEl = document.getElementById("products");
const cartItemsEl = document.getElementById("cartItems");
function renderProducts(){
  productsEl.innerHTML = products.map(p => `<article class="product-card"><div class="product-image" aria-hidden="true">${p.emoji}</div><div class="product-content"><h3>${p.name}</h3><p>${p.description}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">+ Add</button></div></div></article>`).join("");
}
function renderCart(){
  document.getElementById("cartCount").textContent = cart.reduce((n,item)=>n+item.qty,0);
  if(!cart.length){cartItemsEl.innerHTML='<p class="empty">Your cart is empty. Add something tasty!</p>';}
  else {cartItemsEl.innerHTML=cart.map(item=>`<div class="cart-row"><div><strong>${item.emoji} ${item.name}</strong><small>${money(item.price)} each</small></div><div class="cart-actions"><button class="qty-btn" data-minus="${item.id}" aria-label="Decrease quantity">−</button><strong>${item.qty}</strong><button class="qty-btn" data-plus="${item.id}" aria-label="Increase quantity">+</button><strong>${money(item.price*item.qty)}</strong></div></div>`).join("");}
  document.getElementById("cartTotal").textContent=money(cart.reduce((n,item)=>n+item.price*item.qty,0));
}
function toast(message){const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),3000);}
productsEl.addEventListener("click",e=>{const id=Number(e.target.dataset.add);if(!id)return;const p=products.find(x=>x.id===id);const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({...p,qty:1});renderCart();toast(p.name+" added to cart.");});
cartItemsEl.addEventListener("click",e=>{const plus=Number(e.target.dataset.plus),minus=Number(e.target.dataset.minus);if(plus){cart.find(x=>x.id===plus).qty++;}else if(minus){const item=cart.find(x=>x.id===minus);item.qty--;if(item.qty<=0)cart=cart.filter(x=>x.id!==minus);}else return;renderCart();});
document.getElementById("placeOrder").addEventListener("click",()=>{if(!cart.length){toast("Please add a product to your cart first.");return;}const summary=cart.map(x=>`${x.name} x ${x.qty}`).join(", ");toast("Demo order created: "+summary+". Connect a backend to receive real orders.");});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("navLinks").classList.toggle("open"));
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
