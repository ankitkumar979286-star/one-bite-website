# 🍔 One Bite — One loud crunch. Pure joy.

A responsive demo food website created by **Ankit Kumar**.

## Features
- Responsive food landing page
- Sample food product cards
- Add-to-cart and quantity controls
- Cart total calculation
- Demo order confirmation
- Owner, contact, opening-hours and location section

## Files
- `index.html` — website structure
- `style.css` — styling and responsive layout
- `script.js` — products, cart and demo order interactions

## Run locally
Open `index.html` in a browser.

## Before publishing
Edit `index.html` and replace the contact number, opening hours and location placeholders with your correct business details.

## Important
This is a front-end demo. Orders are not sent to a real restaurant or database. A backend is needed for real order processing.
